# it-assetmgmt
manage it assets
streamlit==1.32.2
pandas==2.1.4
duckdb==0.10.0
gspread==6.0.2
google-auth==2.27.0

python-3.11

